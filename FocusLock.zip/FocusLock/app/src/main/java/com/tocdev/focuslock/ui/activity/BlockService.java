package com.tocdev.focuslock.ui.activity;
import android.os.Build;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.IBinder;
import java.util.*;
import android.net.Uri;

public class BlockService extends Service {
    Timer timer;
    @Override
    public int onStartCommand(Intent i, int f, int id){
        timer = new Timer();
        timer.schedule(new TimerTask(){
				public void run(){ check(); }
			}, 0, 800);
        return START_STICKY;
    }
    void check(){
        try{
            UsageStatsManager usm = (UsageStatsManager)getSystemService(USAGE_STATS_SERVICE);
            long now = System.currentTimeMillis();
            UsageEvents events = usm.queryEvents(now-2000, now);
            UsageEvents.Event e = new UsageEvents.Event();
            String top = "";
            while(events.hasNextEvent()){
                events.getNextEvent(e);
                if(e.getEventType() == UsageEvents.Event.MOVE_TO_FOREGROUND){
                    top = e.getPackageName();
                }
            }
            if(top.isEmpty()) return;
            if(top.toLowerCase().contains("focuslock")) return;

            SharedPreferences p = getSharedPreferences("focuslock", MODE_PRIVATE);
			long end = p.getLong("block_end", 0);
            if(System.currentTimeMillis() > end && end!= 0){
                // Time finished, auto clear
                p.edit().putLong("block_end", 0).putStringSet("blocked", new HashSet<String>()).apply();
                return;
            }
            Set<String> blocked = p.getStringSet("blocked", new HashSet<String>());
            if(blocked.contains(top) && System.currentTimeMillis() < end){
                Intent lock = new Intent(BlockService.this, LockActivity.class);
                lock.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                lock.putExtra("pkg", top);
                startActivity(lock);
            }
        }catch(Exception ex){}
    }
    @Override public void onDestroy(){ if(timer!=null) timer.cancel(); super.onDestroy(); }
    @Override public IBinder onBind(Intent i){ return null; }
	
	@Override
    public void onTaskRemoved(Intent rootIntent){
        try{
            Intent restart = new Intent(getApplicationContext(), BlockService.class);
            android.app.PendingIntent pi = android.app.PendingIntent.getService(getApplicationContext(), 1, restart, android.app.PendingIntent.FLAG_ONE_SHOT | android.app.PendingIntent.FLAG_IMMUTABLE);
            android.app.AlarmManager am = (android.app.AlarmManager)getSystemService(ALARM_SERVICE);
            am.set(android.app.AlarmManager.RTC, System.currentTimeMillis()+1000, pi);
        }catch(Exception e){}
        super.onTaskRemoved(rootIntent);
    }
	}
