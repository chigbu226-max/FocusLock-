package com.tocdev.focuslock.ui.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    List<String> appNames, packageNames, filteredNames, filteredPackages;
    List<Drawable> appIcons, filteredIcons;
    Set<String> blockedSet;
    SharedPreferences prefs;
    TextView timerText, statsText;
    CountDownTimer countDown;
    EditText searchBar;
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        timerText = new TextView(this);
        timerText.setPadding(30,40,30,40);
        timerText.setTextSize(18);
        timerText.setGravity(Gravity.CENTER);
        timerText.setTextColor(0xFFFFFFFF);
        timerText.setBackgroundColor(0xFF222222);
        root.addView(timerText);

        // STATS - FOR TOP
        statsText = new TextView(this);
        statsText.setPadding(30,20,30,20);
        statsText.setTextSize(14);
        statsText.setGravity(Gravity.CENTER);
        statsText.setTextColor(0xFF00FF88);
        statsText.setBackgroundColor(0xFF1A1A1A);
        root.addView(statsText);

        searchBar = new EditText(this);
        searchBar.setHint("Search apps...");
        searchBar.setPadding(40,30,40,30);
        searchBar.setBackgroundColor(0xFF111111);
        searchBar.setTextColor(0xFFFFFFFF);
        searchBar.setHintTextColor(0xFF888888);
        root.addView(searchBar);

        listView = new ListView(this);
        root.addView(listView);
        setContentView(root);

        prefs = getSharedPreferences("focuslock", MODE_PRIVATE);
        blockedSet = prefs.getStringSet("blocked", new HashSet<String>());
        Set<String> clean = new HashSet<String>(blockedSet);
        clean.remove("com.tocdev.focuslock");
        clean.remove(getPackageName());
        blockedSet = clean;

        PackageManager pm = getPackageManager();
        List<ApplicationInfo> apps = pm.getInstalledApplications(0);
        appNames = new ArrayList<>();
        packageNames = new ArrayList<>();
        appIcons = new ArrayList<>();

        Map<String, ApplicationInfo> map = new TreeMap<>();
        for (ApplicationInfo app : apps) {
            if (pm.getLaunchIntentForPackage(app.packageName)!= null) {
                String name = pm.getApplicationLabel(app).toString();
                if(!name.equals("FocusLock")){
                    map.put(name, app);
                }
            }
        }
        for (Map.Entry<String, ApplicationInfo> e : map.entrySet()) {
            appNames.add(e.getKey());
            packageNames.add(e.getValue().packageName);
            try{ appIcons.add(pm.getApplicationIcon(e.getValue().packageName)); } catch(Exception ex){ appIcons.add(null); }
        }

        filteredNames = new ArrayList<>(appNames);
        filteredPackages = new ArrayList<>(packageNames);
        filteredIcons = new ArrayList<>(appIcons);

        updateList();
        startTimerLoop();
        updateStats();

        searchBar.addTextChangedListener(new TextWatcher(){
				public void beforeTextChanged(CharSequence s,int a,int b,int c){}
				public void onTextChanged(CharSequence s,int a,int b,int c){}
				public void afterTextChanged(Editable s){
					String q = s.toString().toLowerCase().trim();
					filteredNames.clear(); filteredPackages.clear(); filteredIcons.clear();
					if(q.isEmpty()){
						filteredNames.addAll(appNames);
						filteredPackages.addAll(packageNames);
						filteredIcons.addAll(appIcons);
					} else {
						for(int i=0;i<appNames.size();i++){
							if(appNames.get(i).toLowerCase().contains(q)){
								filteredNames.add(appNames.get(i));
								filteredPackages.add(packageNames.get(i));
								filteredIcons.add(appIcons.get(i));
							}
						}
					}
					updateList();
				}
			});

        if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M){
            if(!Settings.canDrawOverlays(this)){
                Intent oi = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:"+getPackageName()));
                startActivity(oi);
            }
        }

        Intent svc = new Intent(this, BlockService.class);
        if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O){
            startForegroundService(svc);
        } else {
            startService(svc);
        }

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
				@Override
				public void onItemClick(AdapterView<?> p, View v, int pos, long id){
					long endTime = prefs.getLong("block_end", 0);
					long now = System.currentTimeMillis();
					String pkg = filteredPackages.get(pos);
					String name = filteredNames.get(pos);

					if(endTime > now && blockedSet.contains(pkg)){
						long remain = (endTime - now)/1000/60;
						Toast.makeText(MainActivity.this, "FOCUS ACTIVE! "+remain+" mins left", Toast.LENGTH_LONG).show();
						return;
					}
					Set<String> newSet = new HashSet<String>(blockedSet);
					if(newSet.contains(pkg)){
						newSet.remove(pkg);
						Toast.makeText(MainActivity.this, name + " UNBLOCKED", 0).show();
						blockedSet = newSet;
						prefs.edit().putStringSet("blocked", newSet).apply();
						updateList();
					} else {
						if(endTime > now){
							newSet.add(pkg);
							blockedSet = newSet;
							prefs.edit().putStringSet("blocked", newSet).apply();
							updateList();
							Toast.makeText(MainActivity.this, name+" ADDED!", Toast.LENGTH_SHORT).show();
						} else {
							showDurationDialog(pkg, name);
						}
					}
					updateStats();
				}
			});
    }

    void updateStats(){
        int blocks = prefs.getInt("total_blocks",0);
        int sessions = prefs.getInt("sessions",0);
        long totalMins = prefs.getLong("total_focus_time",0)/1000/60;
        statsText.setText("Saved: "+totalMins+"m | Blocks: "+blocks+" | Sessions: "+sessions);
    }

    void showDurationDialog(final String pkg, final String name){
        final String[] options = {"15 mins", "30 mins", "1 hour", "2 hours", "4 hours", "Till tomorrow", "Custom..."};
        final long[] durations = {15*60*1000, 30*60*1000, 60*60*1000, 2*60*60*1000, 4*60*60*1000, 24*60*60*1000, -1};
        new AlertDialog.Builder(this).setTitle("Block "+name+" for?").setItems(options, new DialogInterface.OnClickListener(){
				public void onClick(DialogInterface d, int which){
					if(durations[which] == -1){ showCustomDialog(pkg, name); return; }
					long end = System.currentTimeMillis() + durations[which];
					prefs.edit().putLong("block_end", end).apply();
					prefs.edit().putLong("total_focus_time", prefs.getLong("total_focus_time",0)+durations[which]).apply();
					prefs.edit().putInt("sessions", prefs.getInt("sessions",0)+1).apply();
					Set<String> ns = new HashSet<String>(blockedSet); ns.add(pkg); blockedSet = ns;
					prefs.edit().putStringSet("blocked", ns).apply(); updateList(); startTimerLoop(); updateStats();
					Toast.makeText(MainActivity.this, name+" BLOCKED for "+options[which], Toast.LENGTH_LONG).show();
				}
			}).show();
    }

    void showCustomDialog(final String pkg, final String name){
        LinearLayout layout = new LinearLayout(this); layout.setOrientation(LinearLayout.VERTICAL); layout.setPadding(60,30,60,30);
        final EditText hourInput = new EditText(this); hourInput.setHint("Hours"); hourInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER); layout.addView(hourInput);
        final EditText minInput = new EditText(this); minInput.setHint("Minutes"); minInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER); layout.addView(minInput);
        new AlertDialog.Builder(this).setTitle("Custom Time").setView(layout).setPositiveButton("START", new DialogInterface.OnClickListener(){
				public void onClick(DialogInterface d, int which){
					int h=0,m=0; try{ h=Integer.parseInt(hourInput.getText().toString()); }catch(Exception e){} try{ m=Integer.parseInt(minInput.getText().toString()); }catch(Exception e){}
					if(h==0&&m==0) m=10; long total=(h*60L+m)*60*1000; if(total<60*1000) total=60*1000;
					long end=System.currentTimeMillis()+total; prefs.edit().putLong("block_end", end).apply();
					prefs.edit().putLong("total_focus_time", prefs.getLong("total_focus_time",0)+total).apply();
					prefs.edit().putInt("sessions", prefs.getInt("sessions",0)+1).apply();
					Set<String> ns=new HashSet<String>(blockedSet); ns.add(pkg); blockedSet=ns; prefs.edit().putStringSet("blocked", ns).apply(); updateList(); startTimerLoop(); updateStats();
				}
			}).setNegativeButton("Cancel", null).show();
    }

    void startTimerLoop(){
        if(countDown!= null) countDown.cancel();
        long end = prefs.getLong("block_end", 0); long now = System.currentTimeMillis();
        if(end <= now){ timerText.setText("FocusLock - "+blockedSet.size()+" apps blocked"); return; }
        long diff = end - now;
        countDown = new CountDownTimer(diff, 1000){
            public void onTick(long ms){
                long mins = ms/1000/60; long secs = (ms/1000)%60; long hours = mins/60; mins = mins%60;
                if(hours>0){ timerText.setText("FOCUS ACTIVE - "+hours+"h "+mins+"m "+secs+"s left"); }
                else{ timerText.setText("FOCUS ACTIVE - "+mins+"m "+secs+"s left"); }
            }
            public void onFinish(){
                timerText.setText("Focus finished!");
                prefs.edit().putLong("block_end", 0).putStringSet("blocked", new HashSet<String>()).apply(); blockedSet.clear(); updateList(); updateStats();
            }
        }.start();
    }

    void updateList(){
        listView.setAdapter(new BaseAdapter(){
				public int getCount(){ return filteredNames.size(); }
				public Object getItem(int i){ return filteredNames.get(i); }
				public long getItemId(int i){ return i; }
				public View getView(int pos, View cv, ViewGroup parent){
					LinearLayout row = new LinearLayout(MainActivity.this);
					row.setOrientation(LinearLayout.HORIZONTAL);
					row.setPadding(30,25,30,25);
					row.setGravity(Gravity.CENTER_VERTICAL);
					ImageView iv = new ImageView(MainActivity.this);
					iv.setLayoutParams(new LinearLayout.LayoutParams(120,120));
					Drawable d = filteredIcons.get(pos);
					if(d!=null) iv.setImageDrawable(d);
					row.addView(iv);
					TextView tv = new TextView(MainActivity.this);
					tv.setPadding(30,0,0,0);
					tv.setTextSize(16);
					tv.setTextColor(0xFFFFFFFF);
					String n = filteredNames.get(pos);
					String pkg = filteredPackages.get(pos);
					if(blockedSet.contains(pkg)){
						tv.setText("LOCKED " + n);
						tv.setTextColor(0xFFFF5555);
						row.setBackgroundColor(0xFF331111);
					}else{
						tv.setText(n);
						row.setBackgroundColor(0xFF111111);
					}
					row.addView(tv);
					return row;
				}
			});
    }
}
