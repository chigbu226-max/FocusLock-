package com.tocdev.focuslock.ui.activity;

import android.app.Activity;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.Random;

public class LockActivity extends Activity {
    CountDownTimer timer;
    String[] quotes = {
        "Your future needs you, not your feed.",
        "Focus is the new superpower.",
        "You are not lazy, you are distracted.",
        "5 mins of focus > 1 hour of scrolling.",
        "TikTok will still be there after success.",
        "Discipline is choosing what you want MOST over what you want NOW.",
        "Don't trade your dreams for dopamine.",
        "The phone can wait. Your goals cannot.",
        "Be so focused, distractions get bored.",
        "You blocked it for a reason. Remember why?"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String blockedPkg = getIntent().getStringExtra("pkg");

        // THIS IS THE BLOCK COUNTER - E GO PERSIST FOREVER
        SharedPreferences counter = getSharedPreferences("focuslock", MODE_PRIVATE);
        int oldBlocks = counter.getInt("total_blocks",0);
        counter.edit().putInt("total_blocks", oldBlocks+1).apply();

        SharedPreferences prefs = getSharedPreferences("focuslock", MODE_PRIVATE);
        long end = prefs.getLong("block_end", 0);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(50,50,50,50);
        root.setBackgroundColor(0xFF0F0F0F);

        TextView lock = new TextView(this);
        lock.setText("LOCKED");
        lock.setTextSize(60);
        lock.setGravity(Gravity.CENTER);
        lock.setTextColor(0xFFFF5555);
        root.addView(lock);

        ImageView appIcon = new ImageView(this);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(200,200);
        ip.gravity = Gravity.CENTER;
        ip.topMargin = 30;
        appIcon.setLayoutParams(ip);
        try{
            PackageManager pm = getPackageManager();
            Drawable icon = pm.getApplicationIcon(blockedPkg);
            appIcon.setImageDrawable(icon);
        }catch(Exception e){}
        root.addView(appIcon);

        TextView appName = new TextView(this);
        appName.setGravity(Gravity.CENTER);
        appName.setTextSize(22);
        appName.setTextColor(0xFFFFFFFF);
        appName.setPadding(0,20,0,10);
        try{
            PackageManager pm = getPackageManager();
            ApplicationInfo ai = pm.getApplicationInfo(blockedPkg, 0);
            appName.setText(pm.getApplicationLabel(ai) + " is Locked");
        }catch(Exception e){ appName.setText("App is Locked"); }
        root.addView(appName);

        final TextView countdown = new TextView(this);
        countdown.setGravity(Gravity.CENTER);
        countdown.setTextSize(28);
        countdown.setTextColor(0xFFFF5555);
        countdown.setPadding(0,20,0,20);
        root.addView(countdown);

        TextView quote = new TextView(this);
        quote.setGravity(Gravity.CENTER);
        quote.setTextSize(16);
        quote.setTextColor(0xFFAAAAAA);
        quote.setPadding(30,30,30,30);
        Random r = new Random();
        int idx = r.nextInt(quotes.length);
        quote.setText(quotes[idx]);
        root.addView(quote);

        Button back = new Button(this);
        back.setText("Back to Focus");
        back.setBackgroundColor(0xFF333333);
        back.setTextColor(0xFFFFFFFF);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, 140);
        bp.topMargin = 40;
        back.setLayoutParams(bp);
        back.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){ finish(); }
        });
        root.addView(back);

        setContentView(root);

        long diff = end - System.currentTimeMillis();
        if(diff <= 0) diff = 60000;

        timer = new CountDownTimer(diff, 1000){
            public void onTick(long ms){
                long m = ms/1000/60;
                long s = (ms/1000)%60;
                long h = m/60; m = m%60;
                if(h>0) countdown.setText(h+"h "+m+"m "+s+"s left");
                else countdown.setText(m+"m "+s+"s left");
            }
            public void onFinish(){ finish(); }
        };
        timer.start();
    }
    @Override
    public void onBackPressed() {}
}
